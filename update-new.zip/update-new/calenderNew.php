<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css" type="text/css" />  
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
 body {background-color: white;}
/* calendar */
h2 {background-color:#00FF7F !important;padding-top:10px !important;padding-bottom:10px !important}
/*.calendar       { border-left:1px solid #999; }*/
.calendarday   { min-height:80px; font-size:11px; position:relative; } * html div.calendarday { height:80px; }
.calendarday:hover   { background:#eceff5; }
.calendarEmpty   { background:#eee; min-height:80px; } * html div.calendarEmpty { height:80px; }
.calendarheading { background:#ccc; font-weight:bold; text-align:left; width:120px; padding:22px; border-bottom:1px solid #fff; border-top:1px solid #fff; border-right:1px solid #fff; }
.dayNumber       { padding:5px; color:#000; font-weight:bold; float:right; margin:-5px -5px 0 0; width:20px; text-align:center; }
/* shared */
.calendarday,.calendarEmpty {background-color:#eee;width:120px; padding:22px; border-bottom:1px solid #fff; border-right:1px solid #fff; }

</style>
<body>

  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="flex-container">
<div class="header">
<div class="h1">

  <h4><b> IT207 (Spring 2022) </b></h4>
  <p style="font-size: 20px; margin-top: 20px"> Instructor Name: Erhan Uyar </p> 
      <p> George Mason University </p>
</div>

<div class="h2">
  <h4><b> Kalkidan Meheretu </b></h4>
  <p  style="font-size: 20px; margin-top: 20px">kmeheret@gmu.edu</p> <br />
<?php
  $today = date("h:i M d, Y T", getlastmod());
  echo "Last Modified Time:\t", $today;
?>
</div>
</div>

</div>

      </div>
    </div>
    
      <div class="row">
    <div class="col-md-2">
      <?php include "menu.inc"?>
    </div>
    <div class="col-md-8">
      
      <div>

<?php
/* draws a calendar of given month and year*/
function displayCalendar($month,$year){

   /* draw table */
   $calendar = '<table cellpadding="0" cellspacing="2" class="calendar">';

   /* table headings */
   $calendarheadings = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
   $calendar.= '<tr class="calendar-row"><td class="calendarheading">'.implode('</td><td class="calendarheading">',$calendarheadings).'</td></tr>';

  
   $running_day = date('w',mktime(0,0,0,$month,1,$year));
   $days_in_month = date('t',mktime(0,0,0,$month,1,$year));
   $days_in_this_week = 1;
   $day_counter = 0;
   $dates_array = array();

   /* row for week one */
   $calendar.= '<tr class="calendar-row">';

   /* print "blank" days until the first of the current week */
   for($x = 0; $x < $running_day; $x++):
       $calendar.= '<td class="calendarEmpty"> </td>';
       $days_in_this_week++;
   endfor;

   /* keep going with days.... */
   for($list_day = 1; $list_day <= $days_in_month; $list_day++):
       $calendar.= '<td class="calendarday">';
           /* add in the day number */
           $calendar.= '<div class="dayNumber">'.$list_day.'</div>';

           /** QUERY THE DATABASE FOR AN ENTRY FOR THIS DAY !! IF MATCHES FOUND, PRINT THEM !! **/
           $calendar.= str_repeat('<p> </p>',2);
          
       $calendar.= '</td>';
       if($running_day == 6):
           $calendar.= '</tr>';
           if(($day_counter+1) != $days_in_month):
               $calendar.= '<tr class="calendar-row">';
           endif;
           $running_day = -1;
           $days_in_this_week = 0;
       endif;
       $days_in_this_week++; $running_day++; $day_counter++;
   endfor;

   /* finish the rest of the days in the week */
   if($days_in_this_week < 8):
       for($x = 1; $x <= (8 - $days_in_this_week); $x++):
           $calendar.= '<td class="calendarEmpty"> </td>';
       endfor;
   endif;

   /* final row */
   $calendar.= '</tr>';

   /* end the table */
   $calendar.= '</table>';
  
   /* all done, return result */
   return $calendar;
}

/*get the current month and Year and pass it to draw calendar function*/
$now = new \DateTime('now');
$month = $now->format('m');
$monthName = $now->format('F');
$year = $now->format('Y');
echo "<h2 align='center'>".$monthName." ".$year."</h2>";
echo displayCalendar($month,$year);
?>
</div>
    </div>
    <div class="col-md-2">
  </div>
  </div>

  

</body>
</html>