<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>

    <link rel="stylesheet" href="style.css" type="text/css" />  
    <?php error_reporting(0); ?>

    
    <title>Home Page</title>
    <style type="text/css">
        body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: lightgrey;
  overflow-x: hidden;
  padding-top: 20px;
  margin-right: solid black 1px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 15px;
  color: blue;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
/*  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}


.row {
  width: 100%;
  padding-left: 10px;
}
.row-body {
  width: 100%;
  padding-left: 10px;
  padding-top: 10px;
  padding-bottom: 10px;
  line-height: 2;
}
.row-title {
  width: 100%;
  font-size: 30px;
  padding-left: 10px;
}
.row-head {
  width: 100%;
  font-size: 20px;
  padding-left: 10px;
  padding-top: 10px;
  padding-bottom: 10px;
}
.row-links {
  width: 100%;
  padding-left: 10px;
  padding-top: 10px;
  padding-bottom: 10px;
}
.row-submit {
  width: 100%;
  padding-left: 10px;
  padding-top: 10px;
  padding-bottom: 10px;
}

    </style>

</head>



<body>

<div class="col-container">
    <div>
    <?php include "menu.inc"?>
    </div>
    <div class="col-content main">
         <div>
                     <?php include "header.inc"?>
                </div>
                <div>
                <div class="flex-content">
                    <div style="margin-left: 250px !important;">
                                  <div class="flex-content">
                                    <div class="parent">
                        <?php 
                        
                        
                        $counter = 0;

                        if (!trim($_POST["firstName"]) == ''){
                            $counter+=1; 
                        }
                        if (!trim($_POST["lastName"]) == ''){
                            $counter+=1;
                        }
                        if (!trim($_POST["email"]) == ''){
                            $counter+=1;
                        }
                        if (!trim($_POST["phoneNumber"]) == ''){
                            $counter+=1;
                        }
                        if (!trim($_POST["streetAdress"]) == ''){
                            $counter+=1;
                        }
                        if (!trim($_POST["city"]) == ''){
                            $counter+=1;
                        }
                        if (!trim($_POST["state"]) == ''){
                            $counter+=1;
                        }
                        if (!trim($_POST["zip"]) == ''){
                            $counter+=1;
                        }
                        if (!file_exists("Contacts.txt")){
                            include "nofile.html";
                        }
                        elseif (isset($_POST["add"]) && $counter != 8 ){
                            include "negativeResponse.html";
                        }
                        else {
                            $entry = $_POST["firstName"] . ",";
                            $entry = $entry . $_POST["lastName"] . ",";
                            $entry = $entry . $_POST["email"] . ",";
                            $entry = $entry . $_POST["phoneNumber"] . ",";
                            $entry = $entry . $_POST["streetAdress"] . ",";
                            $entry = $entry . $_POST["city"] . ",";
                            $entry = $entry . $_POST["state"] . ",";
                            $entry = $entry . $_POST["zip"];
                            $entry = $entry . PHP_EOL;                          
                            
                            $file = fopen("Contacts.txt","a+");
                            if (flock($file, LOCK_EX)) {
                                fwrite($file, $entry);
                                flock($file, LOCK_UN);
                                fclose($file);
                            }

                            include "positiveResponse.html";
                                
                            }
                            
                        if (isset($_POST["update"])&& $counter != 8){
                            include "response.html";
                        }
                        else {
                            $entry = $entry  . $_POST["firstName"] . ",";
                            $entry = $entry . $_POST["lastName"] . ",";
                            $entry = $entry . $_POST["email"] . ",";
                            $entry = $entry . $_POST["phoneNumber"] . ",";
                            $entry = $entry . $_POST["streetAdress"] . ",";
                            $entry = $entry . $_POST["city"] . ",";
                            $entry = $entry . $_POST["state"] . ",";
                            $entry = $entry . $_POST["zip"];
                            $entry = $entry . PHP_EOL;
                            
                            $file = fopen("Contacts.txt","w");
                            if (flock($file, LOCK_EX)) {
                               fwrite($file, $entry);
                               flock($file, LOCK_UN);
                               fclose($file);
                            }
                        }
                        ?>
                    </div>
                </div>
              
                </div>
                  <?php include "footer.inc"?>
                </div>
        
    </div>
    
</div>
</div>
</body>


</html>

