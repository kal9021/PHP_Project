<?php
$monday=array();
$tuesday=array();
$wednesday=array();
$thursday=array();
$friday=array();

$monday=$_POST["monday"];
$tuesday=$_POST["tuesday"];
$wednesday=$_POST["wednesday"];
$thursday=$_POST["thursday"];
$friday=$_POST["friday"];

if(isset($_POST['email'])) {
    $monday=array_unique($_POST["monday"]);
    $tuesday=array_unique($_POST["tuesday"]);
    $wednesday=array_unique($_POST["wednesday"]);
    $thursday=array_unique($_POST["thursday"]);
    $friday=array_unique($_POST["friday"]);
}

function timeSlots($day, $weekday, $dayName){
    if(isset($day)){
        foreach ($day as $time){
            $signUpMonth = (int)(date("m"));
            $signUpDay = "/".$weekday;
            $signUpTime = " at " . $time;
            $appointment = $signUpMonth.$signUpDay.$signUpTime;
                
            if (isset($_POST["radio"]) && $_POST["radio"]==$appointment){
                    echo $time . " -- " . $_POST["studentName"] . "<br />";
            }    
            else {
                ?>
              		<input type="radio" name="radio" id="radio<?php echo $weekday?>" value="<?php echo $appointment;?>" required="required"/>
              	<?php
                echo "$time<br/>"; 
                if ($dayName=="monday"){echo '<input type="hidden" name="monday[]" value="'.$time.'">';}
                elseif ($dayName=="tuesday"){echo '<input type="hidden" name="tuesday[]" value="'.$time.'">';}
                elseif ($dayName=="wednesday"){echo '<input type="hidden" name="wednesday[]" value="'.$time.'">';}
                elseif ($dayName=="thursday"){echo '<input type="hidden" name="thursday[]" value="'.$time.'">';}
                else echo '<input type="hidden" name="friday[]" value="'.$time.'">';
            }
        }
    }
}


function firstDay(){
    $d = new DateTime('first day of this month');
    return $d->format('jS, F Y');
}

function weekday($weekday){
    global $weekday;
    if($weekday>=1 && $weekday<= date("t")){
        echo $weekday;
    }
    $weekday+=1;
}

function weekdayMonday($weekday, $monday){
    global $weekday;
    if($weekday>=1 && $weekday<= date("t")){
        echo $weekday, "<br/>";
        timeSlots($monday, $weekday, "monday");
    }
    $weekday+=1;
}


function weekdayTuesday($weekday, $tuesday){
    global $weekday;
    if($weekday>=1 && $weekday<= date("t")){
        echo $weekday, "<br/>";
        timeSlots($tuesday, $weekday, "tuesday");
    }
    $weekday+=1;
}
function weekdayWednesday($weekday, $wednesday){
    global $weekday;
    if($weekday>=1 && $weekday<= date("t")){
        echo $weekday, "<br/>";
        timeSlots($wednesday, $weekday, "wednesday");
    }
    $weekday+=1;
}
function weekdayThursday($weekday, $thursday){
    global $weekday;
    if($weekday>=1 && $weekday<= date("t")){
        echo $weekday, "<br/>";
        timeSlots($thursday, $weekday, "thursday");
    }
    $weekday+=1;
}
function weekdayFriday($weekday, $friday){
    global $weekday;
    if($weekday>=1 && $weekday<= date("t")){
        echo $weekday, "<br/>";
        timeSlots($friday, $weekday, "friday");
    }
    $weekday+=1;
}

?>
                    	
<div class="calendar">
	<div class="row">
		<form method="post" action="<?php echo $_SERVER[" PHP_SELF "];?>">
			<div class="row">
				<h1>Office Hour Sign Up</h1>
			</div>
			<div class="row-head">
				<?php        
				if (isset ($_POST['studentName'])) {
				    $studentName = $_POST['studentName'];
				}
				
				if (isset ($_POST['reset'])) {
				    $studentName = "";
				}
				if (isset ($_POST['studentEmail'])) {
				    $studentEmail = $_POST['studentEmail'];
				}
				if (isset ($_POST['reset'])) {
				    $studentEmail = "";
				}
                ?>
				Student Name: <input type="text" name="studentName" placeholder="Student Name"  required="required" />
				Student Email:<input type="text" name="studentEmail" placeholder="student Email" required="required" />
				<input type="submit" name="email" value="Submit">
				<input type="reset" name="reset" value="Clear">
			</div>
            <br>
			<div class="row">
				<?php
                    if(isset($_POST['email'])) {
                        $message = $studentName . " signed up for office hours for " . $_POST["radio"];
                        if(mail("euyar@gmu.edu", "IT 207 Sign Up", $message, "From:" . "From: Kalkidan Meheretu ".$studentEmail)){
                            echo "Email successfully sent from " . $studentEmail;
                      }
                      else {
                        echo "Email not sent";
                      }
                    }
                ?>
			</div>		
			<div class="row-month">
				<?php 
			         $today = date("F Y");
			         echo $today;
		        ?>
			</div>
			<div class="row">
        		<div class="weekdaySignUp">Sunday</div>
        		<div class="weekdaySignUp">Monday</div>
        		<div class="weekdaySignUp">Tuesday</div>
        		<div class="weekdaySignUp">Wednesday</div>
        		<div class="weekdaySignUp">Thursday</div>
           		<div class="weekdaySignUp">Friday</div>
        		<div class="weekdaySignUp">Saturday</div>
			</div>
			<div class="row">
    		  	<div class="daySignUp">
    		  		<?php
        		  		$d = new DateTime('first day of this month');
        		  		$dt = $d->format('w');
    		  		    
        		  		switch ($dt) {
        		  		    case 0:
        		  		        $weekday = 1;
        		  		        break;
        		  		    case 1:
        		  		        $weekday = 0;
        		  		        break;
        		  		    case 2:
        		  		        $weekday = -1;
        		  		        break;
        		  		    case 3:
        		  		        $weekday = -2;
        		  		        break;
        		  		    case 4:
        		  		        $weekday = -3;
        		  		        break;
        		  		    case 5:
        		  		        $weekday = -4;
        		  		        break;
        		  		    case 6:
        		  		        $weekday = -5;
        		  		        break;
        		  		}        		  		

        		  		weekday($weekday);
    		  		?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekday($weekday, $monday);
    					
					?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayTuesday($weekday, $tuesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
    				<?php
        			weekdayWednesday($weekday, $wednesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
    			    weekdayThursday($weekday, $thursday);
    			    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
    				weekdayFriday($weekday, $friday);
                    ?>
    		  	</div>
    		  	<div class="daySignUp">
					<?php
    				weekday($weekday);
                    ?>
    		  	</div>
		  	</div>
		  	<div class="row">
    		  	<div class="daySignUp">
					<?php
    				weekday($weekday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
                    weekdayMonday($weekday,$monday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayTuesday($weekday, $tuesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayWednesday($weekday, $wednesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayThursday($weekday, $thursday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayFriday($weekday, $friday);
                    ?>
    		  	</div>
    		  	<div class="daySignUp">
					<?php
    				weekday($weekday);
                    ?>
    		  	</div>
		  	</div>
			<div class="row">
    		  	<div class="daySignUp">
    		  		<?php
    				weekday($weekday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayMonday($weekday,$monday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayTuesday($weekday, $tuesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayWednesday($weekday, $wednesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayThursday($weekday, $thursday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayFriday($weekday, $friday);
                    ?>
    		  	</div>
    		  	<div class="daySignUp">
					<?php
    				weekday($weekday);
                    ?>
    		  	</div>
		  	</div>
		  	<div class="row">
    		  	<div class="daySignUp">
					<?php
    				weekday($weekday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayMonday($weekday,$monday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayTuesday($weekday, $tuesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayWednesday($weekday, $wednesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayThursday($weekday, $thursday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayFriday($weekday, $friday);
                    ?>
    		  	</div>
    		  	<div class="daySignUp">
					<?php
    				weekday($weekday);
                    ?>
    		  	</div>
		  	</div>
		  	<div class="row">
    		  	<div class="daySignUp">
					<?php
    				weekday($weekday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayMonday($weekday,$monday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayTuesday($weekday, $tuesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayWednesday($weekday, $wednesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayThursday($weekday, $thursday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayFriday($weekday, $friday);
                    ?>
    		  	</div>
    		  	<div class="daySignUp">
					<?php
    				weekday($weekday);
                    ?>
    		  	</div>
		  	</div>
		  	<div class="row">
    		  	<div class="daySignUp">
					<?php
    				weekday($weekday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayMonday($weekday,$monday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayTuesday($weekday, $tuesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayWednesday($weekday, $wednesday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayThursday($weekday, $thursday);
                    ?>
    		  	</div>
				<div class="daySignUp">
					<?php
					weekdayFriday($weekday, $friday);
                    ?>
    		  	</div>
    		  	<div class="daySignUp">
					<?php
    				weekday($weekday);
                    ?>
    		  	</div>
		  	</div>
		</form>
	</div>
</div>