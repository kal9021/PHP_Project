



<?php
    
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];


  
    
    $entryUpdate = array();
    
    $file = fopen("Contacts.txt", "r");
    $line = array();
    
    while (!feof($file)) {
        $line[] = fgets($file);
    }
    
    fclose($file);
    

    

foreach ($line as $person){
    $person = explode(",",$person);
    
    if ($person[0]==$firstName && $person[1]==$lastName){
        $email = $person[2];
        $phoneNumber = $person[3];
        $streetAdress = $person[4];
        $city = $person[5];
        $state = $person[6];
        $zip = $person[7];
    }
    else {
        $entryUpdate = $person[0] . ",";
        $entryUpdate = $entryUpdate . $person[1] . ",";
        $entryUpdate = $entryUpdate . $person[2] . ",";
        $entryUpdate = $entryUpdate . $person[3] . ",";
        $entryUpdate = $entryUpdate . $person[4] . ",";
        $entryUpdate = $entryUpdate . $person[5] . ",";
        $entryUpdate = $entryUpdate . $person[6] . ",";
        $entryUpdate = $entryUpdate . $person[7];
        $entryUpdate = $entryUpdate . PHP_EOL;
    }
    echo '<input type="hidden" name="entry" value="'.$entryUpdate.'">';

    
}
?>

<div class="parent" style="margin-left: 100px;">
    <form method="post" action="controller.php">
    	<div class="row-title">
    		Online Contacts Directory
    	</div>
    	<div class="row-head">
    		Update Contact
    	</div>
		<div class="row-body">

			First Name: <br> <input type="text" name="firstName" style="width: 380px; height: 20px;"  value="<?php echo $firstName; ?>" /> <br />
			Last Name: <br> <input type="text" name="lastName" style="width: 380px; height: 20px;" value="<?php echo $lastName; ?>" /> <br />
			Email Address: <br> <input type="text" name="email" style="width: 380px; height: 20px;" value="<?php echo $email; ?>" /> <br />
			Phone Number: <br> <input type="text" name="phoneNumber" style="width: 380px; height: 20px;" value="<?php echo $phoneNumber; ?>" /> <br />
			Street Address: <br> <input type="text" name="streetAdress" style="width: 380px; height: 20px;" value="<?php echo $streetAdress; ?>" /> <br />
			City: <br> <input type="text" name="city" style="width: 380px; height: 20px;" value="<?php echo $city; ?>" /> <br />
			<label for="state">State</label>
            <br>
			<select id="state" name="state" style="width: 380px; height: 20px;" >
                <option value="Alabama" <?php echo ($state == "Alabama") ? " SELECTED":""?> > Alabama </option>
                <option value="Alaska" <?php echo ($state == "Alaska") ? " SELECTED":""?> > Alaska </option>
                <option value="Arizona" <?php echo ($state == "Arizona") ? " SELECTED":""?> >Arizona</option>
                <option value="Arkansas" <?php echo ($state == "Arkansas") ? " SELECTED":""?> >Arkansas</option>
                <option value="California" <?php echo ($state == "California") ? " SELECTED":""?> >California</option>
                <option value="Colorado" <?php echo ($state == "Colorado") ? " SELECTED":""?> >Colorado</option>
                <option value="Colorado" <?php echo ($state == "Connecticut") ? " SELECTED":""?> >Connecticut</option>
                <option value="Delaware" <?php echo ($state == "Delaware") ? " SELECTED":""?> >Delaware</option>
                <option value="Florida" <?php echo ($state == "Florida") ? " SELECTED":""?> >Florida</option>
                <option value="Georgia" <?php echo ($state == "Georgia") ? " SELECTED":""?> >Georgia</option>
                <option value="Hawaii" <?php echo ($state == "Hawaii") ? " SELECTED":""?> >Hawaii</option>
                <option value="Idaho" <?php echo ($state == "Idaho") ? " SELECTED":""?> >Idaho</option>
                <option value="Illinois" <?php echo ($state == "Illinois") ? " SELECTED":""?> >Illinois</option>
                <option value="Indiana" <?php echo ($state == "Indiana") ? " SELECTED":""?> >Indiana</option>
                <option value="Iowa" <?php echo ($state == "Iowa") ? " SELECTED":""?> >Iowa</option>
                <option value="Kansas" <?php echo ($state == "Kansas") ? " SELECTED":""?> >Kansas</option>
                <option value="Kentucky" <?php echo ($state == "Kentucky") ? " SELECTED":""?> >Kentucky</option>
                <option value="Louisiana" <?php echo ($state == "Louisiana") ? " SELECTED":""?> >Louisiana</option>
                <option value="Maine" <?php echo ($state == "Maine") ? "SELECTED":""?>>Maine</option>
                <option value="Maryland" <?php echo ($state == "Maryland") ? " SELECTED":""?> >Maryland</option>
                <option value="Massachusetts" <?php echo ($state == "Massachusetts") ? " SELECTED":""?> >Massachusetts</option>
                <option value="Michigan" <?php echo ($state == "Michigan") ? " SELECTED":""?> >Michigan</option>
                <option value="Minnesota" <?php echo ($state == "Minnesota") ? " SELECTED":""?> >Minnesota</option>
                <option value="Mississippi" <?php echo ($state == "Mississippi") ? " SELECTED":""?> >Mississippi</option>
                <option value="Missouri" <?php echo ($state == "Missouri") ? " SELECTED":""?> >Missouri</option>
                <option value="Montana" <?php echo ($state == "Montana") ? " SELECTED":""?> >Montana</option>
                <option value="Nebraska" <?php echo ($state == "Nebraska") ? " SELECTED":""?> >Nebraska</option>
                <option value="Nevada" <?php echo ($state == "Nevada") ? " SELECTED":""?> >Nevada</option>
                <option value="New Hampshire" <?php echo ($state == "New Hampshire") ? " SELECTED":""?> >New Hampshire</option>
                <option value="New Jersey" <?php echo ($state == "New Jersey") ? " SELECTED":""?> >New Jersey</option>
                <option value="New Mexico" <?php echo ($state == "New Mexico") ? " SELECTED":""?> >New Mexico</option>
                <option value="New York" <?php echo ($state == "New York") ? " SELECTED":""?> >New York</option>
                <option value="North Carolina" <?php echo ($state == "North Carolina") ? " SELECTED":""?> >North Carolina</option>
                <option value="North Dakota" <?php echo ($state == "North Dakota") ? " SELECTED":""?> >North Dakota</option>
                <option value="Ohio" <?php echo ($state == "Ohio") ? " SELECTED":""?> >Ohio</option>
                <option value="Oklahoma" <?php echo ($state == "Oklahoma") ? " SELECTED":""?> >Oklahoma</option>
                <option value="Oregon" <?php echo ($state == "Oregon") ? " SELECTED":""?> >Oregon</option>
                <option value="Pennsylvania" <?php echo ($state == "Pennsylvania") ? " SELECTED":""?> >Pennsylvania</option>
                <option value="Rhode Island" <?php echo ($state == "Rhode Island") ? " SELECTED":""?> >Rhode Island</option>
                <option value="South Carolina" <?php echo ($state == "South Carolina") ? " SELECTED":""?> >South Carolina</option>
                <option value="South Dakota" <?php echo ($state == "South Dakota") ? " SELECTED":""?> >South Dakota</option>
                <option value="Tennessee" <?php echo ($state == "Tennessee") ? " SELECTED":""?> >Tennessee</option>
                <option value="Texas" <?php echo ($state == "Texas") ? " SELECTED":""?> >Texas</option>
                <option value="Utah" <?php echo ($state == "Utah") ? " SELECTED":""?> >Utah</option>
                <option value="Utah" <?php echo ($state == "Vermont") ? " SELECTED":""?> >Vermont</option>
                <option value="Virginia" <?php echo ($state == "Virginia") ? " SELECTED":""?> >Virginia</option>
                <option value="WWashingtonA" <?php echo ($state == "Washington") ? " SELECTED":""?> >Washington</option>
                <option value="West Virginia" <?php echo ($state == "West Virginia") ? " SELECTED":""?> >West Virginia</option>
                <option value="Wisconsin" <?php echo ($state == "Wisconsin") ? " SELECTED":""?> >Wisconsin</option>
                <option value="Wyoming" <?php echo ($state == "Wyoming") ? " SELECTED":""?> >Wyoming</option>
                <option value="Washington D.C." <?php echo ($state == "Washington D.C.") ? " SELECTED":""?> >Washington D.C.</option>
			</select>
			<br />
			City: <br> <input type="text" name="zip"  style="width: 380px; height: 20px;" value="<?php echo $zip; ?>" /> <br />
		</div>
		<div class="row-submit">
			<input type="submit" name="update" style="width: 100px; height: 30px;" value="Update Entry" />
		</div>
		<div class="row-urls">
                    <a href="searchContact.php">Return to Directory</a>
                  </div>

	</form>

</div>
<div>
      
</div>
 <!-- my email address is andyokuba@gmail.com

    whatsapp +254759562522


    you can text we schedule a zoom meeting or email me 


    so that we can ensure it works



 -->