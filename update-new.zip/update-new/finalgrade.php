<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="stylesheet" href="style.css" type="text/css" />	
	<title>Final grade Page</title>

</head>



<body>

<?php include "header.inc"?>

<div class="middle">
<?php include "menu.inc"?>

<div class="content">
   

<?php
// define variables
// earned variables
 $earned_participation = $_POST['earnedParticipation'];
 $earned_quiz = $_POST['earnedQuiz'];
 $earned_lab = $_POST['earnedLab'];
 $earned_practica = $_POST['earnedPracticum'];

//  max variables
$max_participation = $_POST['maxParticipation'];
$max_quiz = $_POST['maxQuiz'];
$max_lab= $_POST['maxLab'];
$max_practica = $_POST['maxPracticum'];

// weight variables
$weight_participation = $_POST['weightParticipation'];
$weight_quiz = $_POST['weightQuiz'];
$weight_lab = $_POST['weightLab'];
$weight_practica = $_POST['weightPracticum'];


// function one 
function calc_percentage($earned,$max){
    $count1 = $earned / $max;
    $count = $count1 * 100;
    return $count;
}


// calling function one
$perc_participation = calc_percentage($earned_participation,$max_participation);
$perc_quiz = calc_percentage($earned_quiz,$max_quiz);
$perc_lab = calc_percentage($earned_lab,$max_lab);
$perc_practica = calc_percentage($earned_practica,$max_practica);

// function two
function weighted_percentage($weight,$percentage){
    $count1 = $weight / 100;
    $result = $percentage * $count1;
    return $result;

}

// calling function2
$weighted_participation = weighted_percentage($weight_participation,$perc_participation);
$weighted_quiz = weighted_percentage($weight_quiz,$perc_quiz);
$weighted_lab = weighted_percentage($weight_lab,$perc_lab);
$weighted_practica = weighted_percentage($weight_practica,$perc_practica);


// final grade percentage 
$final_percentage =  $weighted_participation + $weighted_quiz + $weighted_lab  + $weighted_practica;



$letterGrade = '';
     $final_percentage >= 95 ? $letterGrade = "A+" :
     ($final_percentage >= 90 && $final_percentage <= 94 ? $letterGrade = "A":
     ($final_percentage >= 85 && $final_percentage <= 89 ? $letterGrade = "B+":
     ($final_percentage >= 80 && $final_percentage <= 84 ? $letterGrade = "B":
     ($final_percentage >= 75 && $final_percentage <= 79 ? $letterGrade = "C+":
     ($final_percentage >= 70 && $final_percentage <= 74 ? $letterGrade = "C":
     ($final_percentage >= 60 && $final_percentage <= 69 ? $letterGrade = "D":
     ($final_percentage >= 0 && $final_percentage <= 59 ? $letterGrade = "F":
     $letterGrade = "E")))))));


 

echo "You earned a ".$perc_participation.' % '. '  for Participation , ' .' with a weighted value of '. $weighted_participation . ' % <br />';
echo '<br/>';
echo '<br/>';

echo "You earned a ".$perc_quiz.' % '.' for Quizzes ,  ' .' with a weighted value of '. $weighted_quiz . ' % <br />';
echo '<br/>';
echo '<br/>';

echo "You earned a ".$perc_lab.' % '.' for Lab assignments ,  ' .' with a weighted value of '. $weighted_lab . ' % <br />';
echo '<br/>';
echo '<br/>';

echo "You earned a ".$perc_practica.' % '.' for Practica , ' .' with a weighted value of '. $weighted_practica . ' % <br />';
echo '<br/>';
echo '<br/>';

echo " Your final percentage is ". $final_percentage . '% , which is a  ' .  $letterGrade .'<br/>'; 




?>
</div>


</div>

<?php include "footer.inc"?>

<!--
	#include virtual="header.inc"
	#include virtual="menu.inc"
	#include virtual="content.inc"
	#include virtual="footer.inc"
-->

<?php setcookie("username", "Kalkidan", time()+3600); ?>
</body>
</html>

