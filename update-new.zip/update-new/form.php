<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="stylesheet" href="style.css" type="text/css" />	
	<title>Home Page</title>
	<style type="text/css">
		body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: lightgrey;
  overflow-x: hidden;
  padding-top: 20px;
  margin-right: solid black 1px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 15px;
  color: blue;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
/*  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
	</style>

</head>



<body>

<?php include "header.inc"?>

<div class="middle">
<?php include "menu.inc"?>
<?php include "form.inc"?>

</div>

<?php include "footer.inc"?>

<!--
	#include virtual="header.inc"
	#include virtual="menu.inc"
	#include virtual="content.inc"
	#include virtual="footer.inc"
-->

<?php setcookie("username", "Kalkidan", time()+3600); ?>
</body>
</html>