<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>

	<link rel="stylesheet" href="style.css" type="text/css" />	
	
	<title>Home Page</title>
	<style type="text/css">
		body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: lightgrey;
  overflow-x: hidden;
  padding-top: 20px;
  margin-right: solid black 1px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 15px;
  color: blue;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
/*  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
	</style>

</head>



<body>

<div class="col-container">
	<div>
	<?php include "menu.inc"?>
	</div>
	<div class="col-content main">
		 <div>
                     <?php include "header.inc"?>
    	        </div>
    	        <div>
    	        <div class="flex-content">
    	        	<div style="background-color: blue; margin-left: 0px !important;">
    	        	<?php include "content.inc"?>
                <?php include "footer.inc"?>
    	        </div>
    	        </div>
		
	</div>
	
</div>
</div>
</body>


</html>

