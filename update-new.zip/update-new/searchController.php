<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>

    <link rel="stylesheet" href="style.css" type="text/css" />  
   <!--  <?php error_reporting(0); ?>
 -->
    
    <title>Home Page</title>
    <style type="text/css">
        body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: lightgrey;
  overflow-x: hidden;
  padding-top: 20px;
  margin-right: solid black 1px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 15px;
  color: blue;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
/*  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}


.row {
  width: 100%;
  padding-left: 10px;
}
.row-body {
  width: 100%;
  padding-left: 10px;
  padding-top: 10px;
  padding-bottom: 10px;
  line-height: 2;
}
.row-title {
  width: 100%;
  font-size: 30px;
  padding-left: 10px;
}
.row-head {
  width: 100%;
  font-size: 20px;
  padding-left: 10px;
  padding-top: 10px;
  padding-bottom: 10px;
}
.row-links {
  width: 100%;
  padding-left: 10px;
  padding-top: 10px;
  padding-bottom: 10px;
}
.row-submit {
  width: 100%;
  padding-left: 10px;
  padding-top: 10px;
  padding-bottom: 10px;
}

    </style>

</head>



<body>
  <?php


$entryUpdate = array();

  

    
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
    
    
    $file = fopen("Contacts.txt", "r");
    $line = array();
    
    while (!feof($file)) {
        $line[] = fgets($file);
    }
    
    fclose($file);
    
    
    
foreach ($line as $person){
    $person = explode(",",$person);
    
    if ($person[0]==$firstName && $person[1]==$lastName){
        $email = $person[2];
        $phoneNumber = $person[3];
        $streetAdress = $person[4];
        $city = $person[5];
        $state = $person[6];
        $zip = $person[7];
    }
    else {
        $entryUpdate = $person[0] . ",";
        $entryUpdate = $entryUpdate . $person[1] . ",";
        $entryUpdate = $entryUpdate . $person[2] . ",";
        $entryUpdate = $entryUpdate . $person[3] . ",";
        $entryUpdate = $entryUpdate . $person[4] . ",";
        $entryUpdate = $entryUpdate . $person[5] . ",";
        $entryUpdate = $entryUpdate . $person[6] . ",";
        $entryUpdate = $entryUpdate . $person[7];
        $entryUpdate = $entryUpdate . PHP_EOL;
    }
    echo '<input type="hidden" name="entry" value="'.$entryUpdate.'">';
    
}

?>

<div class="col-container">
    <div>
    <?php include "menu.inc"?>
    </div>
    <div class="col-content main">
         <div>
                     <?php include "header.inc"?>
                </div>
                <div>
                <div class="flex-content">
                    <div style="margin-left: 250px !important;">
                                  <div class="flex-content">
                                    <div class="parent">
             <?php 
               if( $_POST["firstName"] == '' || $_POST["lastName"] == '')
               {
                 include "invalidResponse.html";
                  }
     
                  if ($email == ''){
                      include "noPerson.html";
                  }
                 
                  else {
                      include 'editContact.php';
                  }
             ?>
                    </div>
                </div>
              
                </div>
                  <?php include "footer.inc"?>
                </div>
        
    </div>
    
</div>
</div>
</body>


</html>

