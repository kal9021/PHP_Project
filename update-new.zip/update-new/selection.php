<!DOCTYPE HTML>
<HTML>

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="stylesheet" href="style.css" type="text/css" />	
	
	<title>Home Page</title>

</head>
<?php include "header.inc"?>


<?php include "menu.inc"?>
<header>
<link rel="stylesheet" href="calendar.css" type="text/css">
</header>


<br><br>
<form action="book1.php" method="post" style="margin-left: 570px;"> 

Name: <input type="text" name="name" required>
Email: <input type="text" name="email" required><br><br>
Message (Optional): <br>
<textarea name="message" rows="10" cols="50" ></textarea><br><br>
<div class="radio" style="border: 3px solid black; width: 400px;">
<?php

$count1 = 0;
$count2 = 0;
$count3 = 0;
$count4 = 0;
$count5 = 0;

if(isset($_POST['submit'])){
	
	echo ("<div class='rad1'>");
	echo ("<b>Monday: </b>"."<br>");
	if(is_array($_POST['time1']) || is_object($_POST['time1'])){
		foreach($_POST['time1'] as $time1){
			//echo ("Time Selected Monday: ".$time1."<br>");
			//echo ($time1."<br>");
			$mon[$count1]=$time1;
			
			echo ($time1."<input type='radio' id='time1' name='monBooking' value='.$mon[$count1].'>"."<br>");
			
			//echo ("Mon = ".$mon[$count1]."<br>");
			$count1 = $count1+1;
		}
		}else{
			echo ("Make a choice first");
			echo ("<form action='timeselection.php'><button name='submit' type='submit'>Okay</button></form>");
		}
		echo "<br>";
		echo ("</div>");
		echo ("<div class='rad2'>");
		echo ("<b>Tuesday: </b>"."<br>");
		if(is_array($_POST['time2']) || is_object($_POST['time2'])){
		foreach($_POST['time2'] as $time2){
			//echo ("Time Selected Tuesday: ".$time2."<br>");
			//echo ($time2."<br>");
						
			$tue[$count2]=$time2;
			
			echo ($time2."<input type='radio' id='time2' name='tueBooking' value='.$tue[$count2].'>"."<br>");
			
			//echo ("Tue = ".$tue[$count2]."<br>");
			$count2 = $count2+1;
		}
		}else{
			echo ("Make a choice first");
			echo ("<form action='timeselection.php'><button name='submit' type='submit'>Okay</button></form>");
		}
		echo "<br>";
		echo ("</div>");
		
		echo ("<div class='rad3'>");
		
		echo ("<b>Wednesday: </b>"."<br>");
		if(is_array($_POST['time3']) || is_object($_POST['time3'])){
		foreach($_POST['time3'] as $time3){
			//echo ("Time Selected Wednesday: ".$time3."<br>");			
			//echo ($time3."<br>");
			$wed[$count3]=$time3;
			
			echo ($time3."<input type='radio' id='time3' name='wedBooking' value='.$wed[$count3].'>"."<br>");
			
			//echo ("Wed = ".$wed[$count3]."<br>");
			$count3 = $count3+1;
		}
		}else{
			echo ("Make a choice first");
			echo ("<form action='timeselection.php'><button name='submit' type='submit'>Okay</button></form>");
		}
		echo "<br>";
		echo ("</div>");
		
		echo ("<div class='rad4'>");
		
		echo ("<b>Thursday: </b>"."<br>");
		if(is_array($_POST['time4']) || is_object($_POST['time4'])){
		foreach($_POST['time4'] as $time4){
			//echo ("Time Selected Thursday: ".$time4."<br>");
			//echo ($time4."<br>");
			$thu[$count4]=$time4;
			
			echo ($time4."<input type='radio' id='time4' name='thuBooking' value='.$thu[$count4].'>"."<br>");
			
			//echo ("Thur = ".$thu[$count4]."<br>");
			$count4 = $count4+1;
		}
		}else{
			echo ("Make a choice first");
			echo ("<form action='timeselection.php'><button name='submit' type='submit'>Okay</button></form>");
		}
		echo "<br>";
		echo ("</div>");
		
		echo ("<div class='rad5'>");		
		
		echo ("<b>Friday: </b>"."<br>");
		if(is_array($_POST['time5']) || is_object($_POST['time5'])){
		foreach($_POST['time5'] as $time5){
			//echo ("Time Selected Friday: ".$time5."<br>");
			//echo ($time5."<br>");
			$fri[$count5]=$time5;
			
			echo ($time5."<input type='radio' id='time5' name='friBooking' value='.$fri[$count5].'>"."<br>");
			
			//echo ("Fri = ".$fri[$count5]."<br>");
			$count5 = $count5+1;
		}
		}else{
			echo ("Make a choice first");
			echo ("<form action='timeselection.php'><button name='submit' type='submit'>Okay</button></form>");
		}
		echo "<br>";
		echo ("</div>");
	}
	
	echo ("<style>
	.radio div{
		display: inline-block;
		//border: 3px solid black;
		margin-left: 10px;
		vertical-align: top;
	}
	</style>");
	
	/*
	echo ("Count1 = ".$count1."<br>");
	echo ("Count2 = ".$count2."<br>");
	echo ("Count3 = ".$count3."<br>");
	echo ("Count4 = ".$count4."<br>");
	echo ("Count5 = ".$count5."<br>");
*/

//include 'booking.php';

//************************************************************************************************************************************************************



?>
</div>

<br>

<button name="submit" type="submit" style="margin-left: 190px;">Book</button>

</form>
<br>
<?php include "footer.inc"?>
</html>