<!DOCTYPE HTML>
<HTML>

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="stylesheet" href="style.css" type="text/css" />	
	
	<title>Home Page</title>
	<style type="text/css">
		
		body {
			background-color: white;
		}

		table {
			margin-left: 10px;
			height: 400px;
			width: 600px;
			background-color: lightgrey;
		}
		#sel1  {
			height: 300px;
			
		}
		#sel2  {
			height: 300px;
			
		}
		#sel3  {
			height: 300px;
			
		}
		#sel4  {
			height: 300px;
			
		}
		#sel5  {
			height: 300px;
			
		}

	</style>

</head>
<?php include "header.inc"?>

<div class="middle">
<?php include "menu.inc"?>

<div class="form" style="margin-left: 550px;">
<form action="selection.php" method="post">
<!--  Name: <input type="text" name="name" required>    -->
<!--  Email: <input type="text" name="email" required>  -->

<h4>*Please select the available times</h4>
<table style="border: 1px solid white">
<tr style="border: 1px solid white">
<th style="border: 1px solid white">Day:</th>
<th style="border: 1px solid white">Mon</th>
<th style="border: 1px solid white">Tue</th>
<th style="border: 1px solid white">Wed</th>
<th style="border: 1px solid white">Thur</th>
<th style="border: 1px solid white">Fri</th>
</tr>

<tr>

<th style="border: 1px solid white">Time:</th>

<td style="border: 1px solid white" >


<select id="sel1" name="time1[]" required multiple>

<option value="7:00am">7:00am</option><br>
<option value="7:30am">7:30am</option><br>
<option value="8:00am">8:00am</option><br>
<option value="8:30am">8:30am</option><br>
<option value="9:00am">9:00am</option><br>
<option value="9:30am">9:30am</option><br>
<option value="10:00am">10:00am</option><br>
<option value="10:30am">10:30am</option><br>
<option value="11:00am">11:00am</option><br>
<option value="11:30am">11:30am</option><br>
<option value="12:00pm">12:00pm</option><br>
<option value="12:30pm">12:30pm</option><br>
<option value="1:00pm">1:00pm</option><br>
<option value="1:30pm">1:30pm</option><br>
<option value="2:00pm">2:00pm</option><br>
<option value="2:30pm">2:30pm</option><br>
<option value="3:00pm">3:00pm</option><br>
<option value="3:30pm">3:30pm</option><br>
<option value="4:00pm">4:00pm</option><br>
<option value="4:30pm">4:30pm</option><br>
<option value="5:00pm">5:00pm</option><br>
<option value="5:30pm">5:30pm</option><br>
<option value="6:00pm">6:00pm</option><br>
<option value="6:30pm">6:30pm</option><br>
<option value="7:00pm">7:00pm</option><br>
<option value="7:30pm">7:30pm</option><br>
<option value="8:00pm">8:00pm</option><br>
<option value="8:30pm">8:30pm</option><br>
<option value="9:00pm">9:00pm</option><br>
<option value="9:30pm">9:30pm</option><br>
<option value="10:00pm">10:00pm</option><br>

</select>

</td>

<td style="border: 1px solid white" id="two">


<select id="sel2" name="time2[]" required multiple>

<option value="7:00am">7:00am</option><br>
<option value="7:30am">7:30am</option><br>
<option value="8:00am">8:00am</option><br>
<option value="8:30am">8:30am</option><br>
<option value="9:00am">9:00am</option><br>
<option value="9:30am">9:30am</option><br>
<option value="10:00am">10:00am</option><br>
<option value="10:30am">10:30am</option><br>
<option value="11:00am">11:00am</option><br>
<option value="11:30am">11:30am</option><br>
<option value="12:00pm">12:00pm</option><br>
<option value="12:30pm">12:30pm</option><br>
<option value="1:00pm">1:00pm</option><br>
<option value="1:30pm">1:30pm</option><br>
<option value="2:00pm">2:00pm</option><br>
<option value="2:30pm">2:30pm</option><br>
<option value="3:00pm">3:00pm</option><br>
<option value="3:30pm">3:30pm</option><br>
<option value="4:00pm">4:00pm</option><br>
<option value="4:30pm">4:30pm</option><br>
<option value="5:00pm">5:00pm</option><br>
<option value="5:30pm">5:30pm</option><br>
<option value="6:00pm">6:00pm</option><br>
<option value="6:30pm">6:30pm</option><br>
<option value="7:00pm">7:00pm</option><br>
<option value="7:30pm">7:30pm</option><br>
<option value="8:00pm">8:00pm</option><br>
<option value="8:30pm">8:30pm</option><br>
<option value="9:00pm">9:00pm</option><br>
<option value="9:30pm">9:30pm</option><br>
<option value="10:00pm">10:00pm</option><br>

</select>

</td>

<td style="border: 1px solid white" id="three">


<select id="sel3" name="time3[]" required multiple>

<option value="7:00am">7:00am</option><br>
<option value="7:30am">7:30am</option><br>
<option value="8:00am">8:00am</option><br>
<option value="8:30am">8:30am</option><br>
<option value="9:00am">9:00am</option><br>
<option value="9:30am">9:30am</option><br>
<option value="10:00am">10:00am</option><br>
<option value="10:30am">10:30am</option><br>
<option value="11:00am">11:00am</option><br>
<option value="11:30am">11:30am</option><br>
<option value="12:00pm">12:00pm</option><br>
<option value="12:30pm">12:30pm</option><br>
<option value="1:00pm">1:00pm</option><br>
<option value="1:30pm">1:30pm</option><br>
<option value="2:00pm">2:00pm</option><br>
<option value="2:30pm">2:30pm</option><br>
<option value="3:00pm">3:00pm</option><br>
<option value="3:30pm">3:30pm</option><br>
<option value="4:00pm">4:00pm</option><br>
<option value="4:30pm">4:30pm</option><br>
<option value="5:00pm">5:00pm</option><br>
<option value="5:30pm">5:30pm</option><br>
<option value="6:00pm">6:00pm</option><br>
<option value="6:30pm">6:30pm</option><br>
<option value="7:00pm">7:00pm</option><br>
<option value="7:30pm">7:30pm</option><br>
<option value="8:00pm">8:00pm</option><br>
<option value="8:30pm">8:30pm</option><br>
<option value="9:00pm">9:00pm</option><br>
<option value="9:30pm">9:30pm</option><br>
<option value="10:00pm">10:00pm</option><br>

</select>

</td>

<td style="border: 1px solid white" id="four">


<select id="sel4" name="time4[]" required multiple>

<option value="7:00am">7:00am</option><br>
<option value="7:30am">7:30am</option><br>
<option value="8:00am">8:00am</option><br>
<option value="8:30am">8:30am</option><br>
<option value="9:00am">9:00am</option><br>
<option value="9:30am">9:30am</option><br>
<option value="10:00am">10:00am</option><br>
<option value="10:30am">10:30am</option><br>
<option value="11:00am">11:00am</option><br>
<option value="11:30am">11:30am</option><br>
<option value="12:00pm">12:00pm</option><br>
<option value="12:30pm">12:30pm</option><br>
<option value="1:00pm">1:00pm</option><br>
<option value="1:30pm">1:30pm</option><br>
<option value="2:00pm">2:00pm</option><br>
<option value="2:30pm">2:30pm</option><br>
<option value="3:00pm">3:00pm</option><br>
<option value="3:30pm">3:30pm</option><br>
<option value="4:00pm">4:00pm</option><br>
<option value="4:30pm">4:30pm</option><br>
<option value="5:00pm">5:00pm</option><br>
<option value="5:30pm">5:30pm</option><br>
<option value="6:00pm">6:00pm</option><br>
<option value="6:30pm">6:30pm</option><br>
<option value="7:00pm">7:00pm</option><br>
<option value="7:30pm">7:30pm</option><br>
<option value="8:00pm">8:00pm</option><br>
<option value="8:30pm">8:30pm</option><br>
<option value="9:00pm">9:00pm</option><br>
<option value="9:30pm">9:30pm</option><br>
<option value="10:00pm">10:00pm</option><br>

</select>

</td>

<td style="border: 1px solid white" id="five">


<select id="sel5" name="time5[]" required multiple>

<option value="7:00am">7:00am</option><br>
<option value="7:30am">7:30am</option><br>
<option value="8:00am">8:00am</option><br>
<option value="8:30am">8:30am</option><br>
<option value="9:00am">9:00am</option><br>
<option value="9:30am">9:30am</option><br>
<option value="10:00am">10:00am</option><br>
<option value="10:30am">10:30am</option><br>
<option value="11:00am">11:00am</option><br>
<option value="11:30am">11:30am</option><br>
<option value="12:00pm">12:00pm</option><br>
<option value="12:30pm">12:30pm</option><br>
<option value="1:00pm">1:00pm</option><br>
<option value="1:30pm">1:30pm</option><br>
<option value="2:00pm">2:00pm</option><br>
<option value="2:30pm">2:30pm</option><br>
<option value="3:00pm">3:00pm</option><br>
<option value="3:30pm">3:30pm</option><br>
<option value="4:00pm">4:00pm</option><br>
<option value="4:30pm">4:30pm</option><br>
<option value="5:00pm">5:00pm</option><br>
<option value="5:30pm">5:30pm</option><br>
<option value="6:00pm">6:00pm</option><br>
<option value="6:30pm">6:30pm</option><br>
<option value="7:00pm">7:00pm</option><br>
<option value="7:30pm">7:30pm</option><br>
<option value="8:00pm">8:00pm</option><br>
<option value="8:30pm">8:30pm</option><br>
<option value="9:00pm">9:00pm</option><br>
<option value="9:30pm">9:30pm</option><br>
<option value="10:00pm">10:00pm</option><br>

</select>

</td>
</tr>

</table>

<br><br>

<input type="button" id="btnReset" value="Clear" onclick="Reset();" style="margin-left: 190px;" />
<script type="text/javascript">
    function Reset() {
        var listBox = document.getElementById("sel1");
        listBox.selectedIndex = -1;
		
		var listBox = document.getElementById("sel2");
        listBox.selectedIndex = -1;
		
		var listBox = document.getElementById("sel3");
        listBox.selectedIndex = -1;
		
		var listBox = document.getElementById("sel4");
        listBox.selectedIndex = -1;
		
		var listBox = document.getElementById("sel5");
        listBox.selectedIndex = -1;
    }
</script>

<button name="submit" type="submit">Submit</button>

</form>

</div>

</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php include "footer.inc"?>

</HTML>