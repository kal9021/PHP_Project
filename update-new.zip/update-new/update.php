<?php


$entryUpdate = array();

  
  if( $_POST["firstName"] == '' || $_POST["lastName"] == '')
  {
    include "response.html";
  }
    
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
    
    
    $file = fopen("directory.txt", "r");
    $line = array();
    
    while (!feof($file)) {
        $line[] = fgets($file);
    }
    
    fclose($file);
    
    
    
foreach ($line as $person){
    $person = explode(",",$person);
    
    if ($person[0]==$firstName && $person[1]==$lastName){
        $email = $person[2];
        $phoneNumber = $person[3];
        $streetAdress = $person[4];
        $city = $person[5];
        $state = $person[6];
        $zip = $person[7];
    }
    else {
        $entryUpdate = $person[0] . ",";
        $entryUpdate = $entryUpdate . $person[1] . ",";
        $entryUpdate = $entryUpdate . $person[2] . ",";
        $entryUpdate = $entryUpdate . $person[3] . ",";
        $entryUpdate = $entryUpdate . $person[4] . ",";
        $entryUpdate = $entryUpdate . $person[5] . ",";
        $entryUpdate = $entryUpdate . $person[6] . ",";
        $entryUpdate = $entryUpdate . $person[7];
        $entryUpdate = $entryUpdate . PHP_EOL;
    }
    echo '<input type="hidden" name="entry" value="'.$entryUpdate.'">';
    
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<link rel="stylesheet" href="directory.css" type="text/css" />
		<title>Online Contacts Directory</title>
	</head>
	   
	<body>

        <div class="col-container">
            <div class="col-siteMenu">
                <?php include '../../IT207/menu.inc';?>
            </div>
            <div class="col-content">
        	    <div class="flex-containerrow">
                        <?php include '../../IT207/header.php';?>
    	        </div>
    	        <div class="flex-content">
						<?php 
						      if ($email == ''){
						          include "notfound.html";
						      }
						     
						      else {
						          include 'updateForm.php';
						      }
						 ?>
                </div>
    	        <div class="flex-copyright">
    	                <?php include '../../IT207/footer.inc';?>
		        </div>
            </div>
       </div>
	</body>
</html>
